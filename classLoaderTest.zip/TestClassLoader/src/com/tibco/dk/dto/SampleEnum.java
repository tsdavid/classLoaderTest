package com.tibco.dk.dto;

public enum SampleEnum {
	
	THIS,
	SAMPLE,
	ENUM

}
